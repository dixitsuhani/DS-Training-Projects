# Accept a number and print its binary, octal and hexadecimal.

x= int(input("Enter a number: "))
print("Binary Form: ", bin(x))
print("Octal Form: ", oct(x))
print("Hexadecimal Form: ", hex(x))