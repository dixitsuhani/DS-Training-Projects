# Accept a sentence and count the number of words.

sentence = input("Enter a sentence: ")
words = sentence.split()
print(words)
count_words = len(words)
print(count_words)