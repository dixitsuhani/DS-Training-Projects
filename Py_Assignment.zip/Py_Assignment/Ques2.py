# Create a program to check whether a number is even or odd.

num= int(input("Enter a number to check if even or odd: "))
if num%2==0:
    print(f"{num} is even.")
else:
    print(f"{num} is odd.")