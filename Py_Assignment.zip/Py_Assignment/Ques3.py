# Accept a string from user and reverse it.

string= input("Enter some string: ")
print("Reversd String: ", string[::-1])