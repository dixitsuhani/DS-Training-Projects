# Write a python program to merge two dictionaries.

a = {"a": 1, "b": 2}
b = {"c": 3, "d": 4}
merged = {**a, **b}
print(merged)